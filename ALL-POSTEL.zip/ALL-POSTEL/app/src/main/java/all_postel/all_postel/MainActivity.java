package all_postel.all_postel;

        import android.annotation.TargetApi;
        import android.app.Activity;
        import android.content.Intent;
        import android.net.Uri;
        import android.os.Build;
        import android.os.Bundle;
        import android.view.Window;
        import android.view.WindowManager;
        import android.webkit.URLUtil;
        import android.webkit.WebResourceRequest;
        import android.webkit.WebView;
        import android.webkit.WebViewClient;
        import android.widget.Toast;
        import android.view.KeyEvent;

        import android.webkit.JavascriptInterface;
        import android.content.Context;


public class MainActivity extends Activity {

    private WebView mWebview;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        this.setTitle("ALL-POSTEL");
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);

//        CookieSyncManager.createInstance(this);
//        CookieSyncManager.getInstance().startSync();

        mWebview = new WebView(this);
        mWebview.setWebViewClient(new CustomWebViewClient());

        mWebview.getSettings().setJavaScriptEnabled(true);
        mWebview.getSettings().setDomStorageEnabled(true);

        mWebview.addJavascriptInterface(new WebAppInterface(this), "Android");

//        if (Build.VERSION.SDK_INT >= 19) {
//            mWebview.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
//        }

        final Activity activity = this;

        mWebview.setWebViewClient(new WebViewClient() {
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(activity, description, Toast.LENGTH_SHORT).show();
            }

        });

        mWebview.loadUrl("https://mobile.all-postel.ru");
//        mWebview.loadUrl("file:///android_asset/test.html");
        setContentView(mWebview);

    }


    @Override
    public void onBackPressed() {
        // super.onBackPressed();
        mWebview.loadUrl("javascript: appBack();");
    }



    public class WebAppInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        WebAppInterface(Context c) {
            mContext = c;
        }

        @JavascriptInterface
        public void appExit() {
            finish();
            return;
        }
    }


    private class CustomWebViewClient extends WebViewClient {

        //@SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {

            if (url.startsWith("tel:")) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse(url));
                startActivity(intent);
                return true;
            }
            return false;
        }
    }


//        @TargetApi(Build.VERSION_CODES.N)
//        @Override
//        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
//            final Uri uri = request.getUrl();
//
////            if( URLUtil.isNetworkUrl(uri.toString()) ) {
////                return false;
////            }
//            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(uri.toString())));
//            return true;
//        }
    }

}
